#include <string.h>
#include "iostream"
#include <limits>
#include "GenFunctions.h"

int DisplayMenuItems(vector<string>& Items)
{
	unsigned int i = (unsigned int)Items.size();
	cout << "\nSupported Methods...\n";

	for (i = 0; i < Items.size(); ++i)
	{
		cout << "\n" << (i + 1) << "." << Items[i];
	}
	cout << "\nEnter Method number (1 to N, 0 for exit...)\n";
	cin >> i;

	cin.ignore(numeric_limits<streamsize>::max(), '\n');

	return i;
}
