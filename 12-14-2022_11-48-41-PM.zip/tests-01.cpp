#include <string>
#include <vector>
#include "iostream"
using namespace std;

#include <string.h>
#include "CaesarGen.h"
#include "tests-01.h"

int tests::test01_caesar01()
{
	cout << "\nRunning test test01_caesar01()...\n";
	Caesar cs;

	string str;
	cout << "Enter text to Encrypt...\n";

	//cin.ignore(numeric_limits<streamsize>::max(), '\n');
	getline(cin, str);

	unsigned int sz = (unsigned int)str.size() + 10;
	unsigned int szn = sz;
	char* pDecodeStr = new char[sz];
	char* pOrig = new char[sz];
	char* pFinal = new char[sz];
	strcpy_s(pOrig, sz, str.c_str());

	int decodeSize = cs.Encode(pOrig, (unsigned int)str.size(), pDecodeStr, szn);
	pDecodeStr[decodeSize] = 0;

	cout << "\nEncoded str...\n" << pDecodeStr << '\n';

	int FinalSize = cs.Decode(pDecodeStr, decodeSize, pFinal, sz);
	pFinal[FinalSize] = 0;
	cout << "\nDecoded str...\n" << pFinal << '\n';

	if (strcmp(pOrig, pFinal))
	{
		cout << "\n:(  Doesn't Match...\n";
		return 0;
	}

	cout << "\n:)  Match. Good Work !!!\n";
	return 1;
}

int tests::test01_caesar02()
{
	cout << "\nRunning test test01_caesar02()...\n";

	Crypto* pcs = new Caesar;
	string str;
	cout << "\nEnter text to Encrypt...\n";
	//cin >> str;
	//cin.clear();
	//fflush(stdin);
//	cin.ignore(numeric_limits<streamsize>::max(), '\n');

	getline(cin, str);

	unsigned int sz = (unsigned int)str.size() + 10;
	unsigned int szn = sz;
	char* pDecodeStr = new char[sz];
	char* pOrig = new char[sz];
	char* pFinal = new char[sz];
	strcpy_s(pOrig, sz, str.c_str());

	int decodeSize = pcs->Encode(pOrig, (unsigned int)str.size(), pDecodeStr, szn);
	pDecodeStr[decodeSize] = 0;

	cout << "\nEncoded str...\n" << pDecodeStr << '\n';

	int FinalSize = pcs->Decode(pDecodeStr, decodeSize, pFinal, sz);
	pFinal[FinalSize] = 0;
	cout << "\nDecoded str...\n" << pFinal << '\n';

	if (strcmp(pOrig, pFinal))
	{
		cout << "\n:(  Doesn't Match...\n";
		return 0;
	}

	cout << "\n:)  Match. Good Work !!!\n";
	delete pcs;
	return 1;
}

int tests::test02_shablon01()
{
    Shablon shb;
    string s = "this year";
    string realresult = shb.Decode(s);
    string unrealresult = encoder(realresult);
    cout << realresult << endl << unrealresult;
    return 1;
}
