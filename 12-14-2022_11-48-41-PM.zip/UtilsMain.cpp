#include <string.h>
#include <string>
#include <vector>
#include "iostream"

#include "GenFunctions.h"
#include "CaesarGen.h"
#include "tests-01.h"

using namespace std;
using namespace tests;

int main(int argc, char* argv[])
{
	vector<string> MenuItems = {
	"  Caesar." ,
	"  Shablon."
	};

	cout << "\nProgram " << argv[0] << ". command line arguments = " << argc << endl;

	unsigned int ItemNum = DisplayMenuItems(MenuItems);
	if (0 == ItemNum)
		exit(0);
	ItemNum--;
	if (ItemNum >= MenuItems.size())
	{
		cout << '\n' << ItemNum << "  Doesn't exist. Terminate...\n";
		exit(0);
	}
	//cin.ignore(numeric_limits<streamsize>::max(), '\n');
	switch(ItemNum)
	{
		case 0:
			cout << "Selected method is  " << MenuItems[ItemNum];
			if (!tests::test01_caesar01())
				cout << "\nTest test01_caesar01() failed\n";

			if (!tests::test01_caesar02())
				cout << "\nTest test01_caesar02() failed\n";

			break;
        case 2:
			cout << "Selected method is  " << MenuItems[ItemNum];
			if (!tests::test02_shablon01())
				cout << "\nTest test01_caesar01() failed\n";

			break;
		default:
			exit(0);
	}


	return 0;
}
