#include "Shablon.h"
#include <cstdio>

    Shablon::~Shablon()
    {
        printf("\nDestructor Shablon.\n");
    }

    char *Shablon::Encoder(string s)
    {
        int j;
        int i = 0;

        while(s[i]){
            j = 0;
            while(unreal[j]){
                if(s[i] == unreal[j]){
                    s[i] = real[j];
                    break;
                }
                j++;
            }
            i++;
        }
        return s;
   }

    char *Shablon::Decoder(string s)
    {
        int j;
        int i = 0;

        while(s[i]){
            j = 0;
            while(real[j]){
                if(s[i] == real[j]){
                    s[i] = unreal[j];
                    break;
                }
                j++;
            }
            i++;
        }

        return s;
    }



