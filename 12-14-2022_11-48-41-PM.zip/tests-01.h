#pragma once

namespace tests
{
	int test01_caesar01();
	int test01_caesar02();
	int test02_shablon01();
};
