#pragma once

#include <string>
#include <vector>
using namespace std;

int DisplayMenuItems(vector<string>& Items);
