#pragma once
#include "Crypto.h"


class Shablon : public Crypto
{
public:
	char *Encoder(string s);
    char *Decoder(string s);
    virtual ~Shablon();

};
